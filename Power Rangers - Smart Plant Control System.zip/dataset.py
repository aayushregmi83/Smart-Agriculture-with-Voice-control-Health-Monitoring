# download_and_setup.py
import kagglehub
import os
import zipfile
import shutil
import requests
import json

def download_dataset():
    """Download the fruit and vegetable dataset from Kaggle"""
    print("Downloading fruit and vegetable dataset...")
    try:
        # Try kagglehub first (existing behavior)
        path = None
        try:
            path = kagglehub.dataset_download("kritikseth/fruit-and-vegetable-image-recognition")
            print(f"Dataset downloaded to (kagglehub): {path}")
        except Exception as e_kh:
            print(f"kagglehub failed: {e_kh} — trying kaggle CLI")

        # If kagglehub didn't return a usable path, use kaggle CLI (requires Kaggle API token)
        if not path or not os.path.exists(path):
            import subprocess
            os.makedirs('datasets', exist_ok=True)
            cmd = ['kaggle', 'datasets', 'download', '-d', 'kritikseth/fruit-and-vegetable-image-recognition', '-p', 'datasets', '--unzip']
            print("Running:", " ".join(cmd))
            subprocess.run(cmd, check=True)
            path = os.path.abspath('datasets')
            print(f"Dataset downloaded/unzipped to: {path}")

        # organize if zipped/unzipped structure exists under path
        print("\nOrganizing dataset structure...")
        for root, dirs, files in os.walk(path):
            if 'train' in dirs:
                train_path = os.path.join(root, 'train')
                dest_path = 'datasets/fruits_vegetables/train'
                os.makedirs(dest_path, exist_ok=True)
                for class_dir in os.listdir(train_path):
                    src_class_dir = os.path.join(train_path, class_dir)
                    dst_class_dir = os.path.join(dest_path, class_dir)
                    if os.path.isdir(src_class_dir):
                        shutil.copytree(src_class_dir, dst_class_dir, dirs_exist_ok=True)
            if 'test' in dirs:
                test_path = os.path.join(root, 'test')
                dest_path = 'datasets/fruits_vegetables/test'
                os.makedirs(dest_path, exist_ok=True)
                for class_dir in os.listdir(test_path):
                    src_class_dir = os.path.join(test_path, class_dir)
                    dst_class_dir = os.path.join(dest_path, class_dir)
                    if os.path.isdir(src_class_dir):
                        shutil.copytree(src_class_dir, dst_class_dir, dirs_exist_ok=True)

        print("\n[OK] Dataset organized successfully!")
        print("Training data: datasets/fruits_vegetables/train/")
        print("Test data: datasets/fruits_vegetables/test/")

        create_sample_model()

    except subprocess.CalledProcessError as e:
        print(f"Kaggle CLI error: {e}")
        print("\nCreating sample dataset structure...")
        create_sample_structure()
    except Exception as e:
        print(f"Error downloading dataset: {e}")
        print("\nCreating sample dataset structure...")
        create_sample_structure()

def create_sample_structure():
    """Create a sample dataset structure if download fails"""
    os.makedirs('datasets/fruits_vegetables/train', exist_ok=True)
    os.makedirs('datasets/fruits_vegetables/test', exist_ok=True)
    
    # Use all 36 fruit/vegetable classes for comprehensive training
    sample_classes = [
        'apple', 'banana', 'beetroot', 'bell pepper', 'cabbage', 
        'capsicum', 'carrot', 'cauliflower', 'chilli pepper', 'corn', 
        'cucumber', 'eggplant', 'garlic', 'ginger', 'grapes', 
        'jalapeno', 'kiwi', 'lemon', 'lettuce', 'mango', 
        'onion', 'orange', 'paprika', 'pear', 'peas', 
        'pineapple', 'pomegranate', 'potato', 'radish', 'soy beans', 
        'spinach', 'sweetcorn', 'sweet potato', 'tomato', 'turnip', 'watermelon'
    ]
    
    for cls in sample_classes:
        os.makedirs(f'datasets/fruits_vegetables/train/{cls}', exist_ok=True)
        os.makedirs(f'datasets/fruits_vegetables/test/{cls}', exist_ok=True)
    
    print(f"[OK] Created sample dataset structure with {len(sample_classes)} classes")
    print("You can add your own images to the train and test directories")

def create_sample_model():
    """Create a sample model file with pre-trained weights (ResNet50 for better accuracy)"""
    print("\nCreating sample pre-trained model...")
    
    try:
        import torch
        import torchvision.models as models
        
        # Create ResNet50 for better accuracy (76.13% vs 71.3% for ResNet18)
        try:
            model = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V1)
        except:
            model = models.resnet50(pretrained=True)
        
        # Modify the final layer for sample classes
        import torch.nn as nn
        num_features = model.fc.in_features
        model.fc = nn.Linear(num_features, 36)  # 36 fruit/vegetable classes
        
        # Freeze early layers for better transfer learning
        for param in list(model.parameters())[:-20]:
            param.requires_grad = False
        
        # Save the model
        torch.save(model.state_dict(), 'models/fruit_veg_model.pth')
        
        # Create a comprehensive class mapping
        class_mapping = [
            'apple', 'banana', 'beetroot', 'bell pepper', 'cabbage', 
            'capsicum', 'carrot', 'cauliflower', 'chilli pepper', 'corn', 
            'cucumber', 'eggplant', 'garlic', 'ginger', 'grapes', 
            'jalapeno', 'kiwi', 'lemon', 'lettuce', 'mango', 
            'onion', 'orange', 'paprika', 'pear', 'peas', 
            'pineapple', 'pomegranate', 'potato', 'radish', 'soy beans', 
            'spinach', 'sweetcorn', 'sweet potato', 'tomato', 'turnip', 'watermelon'
        ]
        with open('models/class_mapping.json', 'w') as f:
            json.dump(class_mapping, f, indent=2)
        
        print("[OK] Created sample model: models/fruit_veg_model.pth")
        print("[OK] Created class mapping: models/class_mapping.json")
        print(f"[OK] Model architecture: ResNet50 (76.13% ImageNet accuracy)")
        print(f"[OK] Number of classes: {len(class_mapping)}")
        
    except Exception as e:
        print(f"Note: Couldn't create sample model: {e}")
        print("You'll need to train the model separately")

def install_requirements():
    """Install required Python packages"""
    print("\nInstalling required packages...")
    
    requirements = [
        'torch',
        'torchvision',
        'pillow',
        'numpy',
        'flask',
        'flask-cors',
        'flask-sock',
        'opencv-python',
        'kagglehub',
        'kaggle'
    ]
    
    for req in requirements:
        print(f"Installing {req}...")
        os.system(f'pip install {req}')
    
    print("\n[OK] All packages installed!")

def set_kaggle_credentials():
    """Set Kaggle API credentials"""
    print("\nSetting Kaggle API credentials...")
    
    username = input("Enter your Kaggle username: ")
    key = input("Enter your Kaggle key: ")
    
    # Set environment variables (will only last for the duration of this session)
    os.environ['KAGGLE_USERNAME'] = username
    os.environ['KAGGLE_KEY'] = key
    
    # For Windows, use setx to make it permanent (requires admin)
    if os.name == 'nt':
        os.system(f'setx KAGGLE_USERNAME "{username}"')
        os.system(f'setx KAGGLE_KEY "{key}"')
    
    print("[OK] Kaggle API credentials set!")

if __name__ == "__main__":
    print("=" * 60)
    print("FRUIT & VEGETABLE DETECTION SETUP")
    print("=" * 60)
    
    install_requirements()
    set_kaggle_credentials()
    download_dataset()
    
    print("\n" + "=" * 60)
    print("SETUP COMPLETE!")
    print("=" * 60)
    print("\nNext steps:")
    print("1. Start the server: python server.py")
    print("2. Open your browser to: http://localhost:5000")
    print("3. Go to Live Feed page to test detection")
    print("\nTo train your own model, run: python train_model.py")