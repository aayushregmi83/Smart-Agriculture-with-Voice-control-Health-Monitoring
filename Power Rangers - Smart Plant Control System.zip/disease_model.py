# disease_model.py - Plant Disease Detection Model
import torch
import torch.nn as nn
from torchvision import models

class PlantDiseaseModel(nn.Module):
    """
    Disease Detection Model for PlantVillage Dataset
    Flexible number of disease classes (15-38 classes)
    """
    def __init__(self, num_classes=38):
        super(PlantDiseaseModel, self).__init__()
        
        # Use ResNet50 pretrained on ImageNet
        try:
            self.model = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V1)
        except:
            self.model = models.resnet50(pretrained=True)
        
        # Modify final layer for disease classification
        num_features = self.model.fc.in_features
        self.model.fc = nn.Linear(num_features, num_classes)
    
    def forward(self, x):
        return self.model(x)

# PlantVillage Dataset Classes (38 classes)
DISEASE_CLASSES = [
    'Apple___Apple_scab',
    'Apple___Black_rot',
    'Apple___Cedar_apple_rust',
    'Apple___healthy',
    'Blueberry___healthy',
    'Cherry_(including_sour)___Powdery_mildew',
    'Cherry_(including_sour)___healthy',
    'Corn_(maize)___Cercospora_leaf_spot Gray_leaf_spot',
    'Corn_(maize)___Common_rust_',
    'Corn_(maize)___Northern_Leaf_Blight',
    'Corn_(maize)___healthy',
    'Grape___Black_rot',
    'Grape___Esca_(Black_Measles)',
    'Grape___Leaf_blight_(Isariopsis_Leaf_Spot)',
    'Grape___healthy',
    'Orange___Haunglongbing_(Citrus_greening)',
    'Peach___Bacterial_spot',
    'Peach___healthy',
    'Pepper,_bell___Bacterial_spot',
    'Pepper,_bell___healthy',
    'Potato___Early_blight',
    'Potato___Late_blight',
    'Potato___healthy',
    'Raspberry___healthy',
    'Soybean___healthy',
    'Squash___Powdery_mildew',
    'Strawberry___Leaf_scorch',
    'Strawberry___healthy',
    'Tomato___Bacterial_spot',
    'Tomato___Early_blight',
    'Tomato___Late_blight',
    'Tomato___Leaf_Mold',
    'Tomato___Septoria_leaf_spot',
    'Tomato___Spider_mites Two-spotted_spider_mite',
    'Tomato___Target_Spot',
    'Tomato___Tomato_Yellow_Leaf_Curl_Virus',
    'Tomato___Tomato_mosaic_virus',
    'Tomato___healthy'
]

# Disease Information Database
DISEASE_INFO = {
    'Apple___Apple_scab': {
        'crop': 'Apple',
        'disease': 'Apple Scab',
        'severity': 'Medium',
        'symptoms': 'Dark, scaly lesions on leaves and fruit; premature leaf drop',
        'treatment': 'Apply fungicide; remove infected leaves; improve air circulation',
        'prevention': 'Plant resistant varieties; avoid overhead watering; prune regularly'
    },
    'Apple___Black_rot': {
        'crop': 'Apple',
        'disease': 'Black Rot',
        'severity': 'High',
        'symptoms': 'Purple spots with white centers; fruit rot; branch cankers',
        'treatment': 'Prune infected areas; apply copper fungicide; remove mummified fruits',
        'prevention': 'Good sanitation; proper pruning; remove dead wood'
    },
    'Apple___Cedar_apple_rust': {
        'crop': 'Apple',
        'disease': 'Cedar Apple Rust',
        'severity': 'Medium',
        'symptoms': 'Yellow-orange spots on leaves; rusty pustules; defoliation',
        'treatment': 'Apply fungicide in spring; remove nearby cedar trees if possible',
        'prevention': 'Plant resistant varieties; maintain distance from cedar trees'
    },
    'Apple___healthy': {
        'crop': 'Apple',
        'disease': 'Healthy',
        'severity': 'None',
        'symptoms': 'No disease symptoms detected',
        'treatment': 'Continue regular care and monitoring',
        'prevention': 'Maintain good cultural practices'
    },
    'Tomato___Bacterial_spot': {
        'crop': 'Tomato',
        'disease': 'Bacterial Spot',
        'severity': 'High',
        'symptoms': 'Small dark spots with yellow halos; leaf drop; fruit spots',
        'treatment': 'Remove infected plants; apply copper spray weekly',
        'prevention': 'Use disease-free seeds; avoid working with wet plants'
    },
    'Tomato___Early_blight': {
        'crop': 'Tomato',
        'disease': 'Early Blight',
        'severity': 'Medium',
        'symptoms': 'Brown spots with target-like rings; yellow halos; lower leaf damage',
        'treatment': 'Remove infected leaves; apply fungicide; mulch soil',
        'prevention': 'Crop rotation; proper spacing; avoid wetting foliage'
    },
    'Tomato___Late_blight': {
        'crop': 'Tomato',
        'disease': 'Late Blight',
        'severity': 'Critical',
        'symptoms': 'Water-soaked lesions; white mold on undersides; rapid death',
        'treatment': 'Remove and destroy plants immediately; apply copper fungicide',
        'prevention': 'Use resistant varieties; avoid overhead irrigation; ensure drainage'
    },
    'Tomato___Leaf_Mold': {
        'crop': 'Tomato',
        'disease': 'Leaf Mold',
        'severity': 'Medium',
        'symptoms': 'Yellow spots on top; olive-green mold underneath; leaf curl',
        'treatment': 'Improve ventilation; reduce humidity; apply fungicide',
        'prevention': 'Greenhouse ventilation; resistant varieties'
    },
    'Tomato___Septoria_leaf_spot': {
        'crop': 'Tomato',
        'disease': 'Septoria Leaf Spot',
        'severity': 'Medium',
        'symptoms': 'Small circular spots with dark borders; gray centers; defoliation',
        'treatment': 'Remove infected leaves; mulch; apply fungicide',
        'prevention': 'Crop rotation; avoid overhead watering'
    },
    'Tomato___Spider_mites Two-spotted_spider_mite': {
        'crop': 'Tomato',
        'disease': 'Spider Mites',
        'severity': 'Medium',
        'symptoms': 'Tiny yellow speckles; fine webbing; bronze leaves',
        'treatment': 'Spray with water; apply neem oil or insecticidal soap',
        'prevention': 'Maintain humidity; avoid over-fertilizing'
    },
    'Tomato___Target_Spot': {
        'crop': 'Tomato',
        'disease': 'Target Spot',
        'severity': 'Medium',
        'symptoms': 'Concentric rings on leaves; brown spots; defoliation',
        'treatment': 'Apply fungicide; remove infected leaves',
        'prevention': 'Proper spacing; avoid overhead watering'
    },
    'Tomato___Tomato_Yellow_Leaf_Curl_Virus': {
        'crop': 'Tomato',
        'disease': 'Yellow Leaf Curl Virus',
        'severity': 'Critical',
        'symptoms': 'Upward leaf curling; yellowing; stunted growth; reduced fruit',
        'treatment': 'Remove infected plants; control whiteflies',
        'prevention': 'Use resistant varieties; control whitefly populations'
    },
    'Tomato___Tomato_mosaic_virus': {
        'crop': 'Tomato',
        'disease': 'Mosaic Virus',
        'severity': 'High',
        'symptoms': 'Mottled light/dark green leaves; distorted leaves; reduced yield',
        'treatment': 'Remove and destroy infected plants (no cure)',
        'prevention': 'Use virus-free seeds; disinfect tools; control aphids'
    },
    'Tomato___healthy': {
        'crop': 'Tomato',
        'disease': 'Healthy',
        'severity': 'None',
        'symptoms': 'No disease symptoms detected',
        'treatment': 'Continue regular care and monitoring',
        'prevention': 'Maintain good cultural practices'
    },
    'Potato___Early_blight': {
        'crop': 'Potato',
        'disease': 'Early Blight',
        'severity': 'Medium',
        'symptoms': 'Dark brown spots with concentric rings; stem lesions',
        'treatment': 'Apply fungicide; remove infected foliage',
        'prevention': 'Crop rotation; proper spacing; resistant varieties'
    },
    'Potato___Late_blight': {
        'crop': 'Potato',
        'disease': 'Late Blight',
        'severity': 'Critical',
        'symptoms': 'Water-soaked lesions; white fungal growth; tuber rot',
        'treatment': 'Apply fungicide immediately; destroy infected plants',
        'prevention': 'Plant certified seed potatoes; ensure good drainage'
    },
    'Potato___healthy': {
        'crop': 'Potato',
        'disease': 'Healthy',
        'severity': 'None',
        'symptoms': 'No disease symptoms detected',
        'treatment': 'Continue regular care and monitoring',
        'prevention': 'Maintain good cultural practices'
    },
    'Pepper,_bell___Bacterial_spot': {
        'crop': 'Bell Pepper',
        'disease': 'Bacterial Spot',
        'severity': 'High',
        'symptoms': 'Small raised spots; yellow halos; leaf drop',
        'treatment': 'Remove infected plants; copper spray',
        'prevention': 'Disease-free seeds; avoid overhead watering'
    },
    'Pepper,_bell___healthy': {
        'crop': 'Bell Pepper',
        'disease': 'Healthy',
        'severity': 'None',
        'symptoms': 'No disease symptoms detected',
        'treatment': 'Continue regular care and monitoring',
        'prevention': 'Maintain good cultural practices'
    },
    'Corn_(maize)___Cercospora_leaf_spot Gray_leaf_spot': {
        'crop': 'Corn',
        'disease': 'Gray Leaf Spot',
        'severity': 'Medium',
        'symptoms': 'Rectangular gray-brown lesions parallel to veins',
        'treatment': 'Apply fungicide; remove debris',
        'prevention': 'Crop rotation; resistant hybrids'
    },
    'Corn_(maize)___Common_rust_': {
        'crop': 'Corn',
        'disease': 'Common Rust',
        'severity': 'Medium',
        'symptoms': 'Small reddish-brown pustules on leaves',
        'treatment': 'Apply fungicide if severe; plant resistant hybrids',
        'prevention': 'Use resistant varieties; proper spacing'
    },
    'Corn_(maize)___Northern_Leaf_Blight': {
        'crop': 'Corn',
        'disease': 'Northern Leaf Blight',
        'severity': 'High',
        'symptoms': 'Long gray-green lesions (6-12 inches); cigar-shaped',
        'treatment': 'Apply fungicide; remove infected leaves',
        'prevention': 'Resistant varieties; crop rotation'
    },
    'Corn_(maize)___healthy': {
        'crop': 'Corn',
        'disease': 'Healthy',
        'severity': 'None',
        'symptoms': 'No disease symptoms detected',
        'treatment': 'Continue regular care and monitoring',
        'prevention': 'Maintain good cultural practices'
    },
    'Grape___Black_rot': {
        'crop': 'Grape',
        'disease': 'Black Rot',
        'severity': 'High',
        'symptoms': 'Brown circular spots on leaves; mummified berries',
        'treatment': 'Remove infected fruit; apply fungicide',
        'prevention': 'Pruning for air circulation; sanitation'
    },
    'Grape___Esca_(Black_Measles)': {
        'crop': 'Grape',
        'disease': 'Esca (Black Measles)',
        'severity': 'Critical',
        'symptoms': 'Tiger-stripe pattern on leaves; dried berries; wood decay',
        'treatment': 'Prune infected wood (no complete cure)',
        'prevention': 'Proper pruning techniques; wound protection'
    },
    'Grape___Leaf_blight_(Isariopsis_Leaf_Spot)': {
        'crop': 'Grape',
        'disease': 'Leaf Blight',
        'severity': 'Medium',
        'symptoms': 'Brown spots with yellow margins; defoliation',
        'treatment': 'Apply fungicide; improve air flow',
        'prevention': 'Canopy management; resistant varieties'
    },
    'Grape___healthy': {
        'crop': 'Grape',
        'disease': 'Healthy',
        'severity': 'None',
        'symptoms': 'No disease symptoms detected',
        'treatment': 'Continue regular care and monitoring',
        'prevention': 'Maintain good cultural practices'
    },
    'Strawberry___Leaf_scorch': {
        'crop': 'Strawberry',
        'disease': 'Leaf Scorch',
        'severity': 'Medium',
        'symptoms': 'Purple to brown blotches; scorched appearance',
        'treatment': 'Remove infected leaves; fungicide spray',
        'prevention': 'Proper spacing; avoid overhead watering'
    },
    'Strawberry___healthy': {
        'crop': 'Strawberry',
        'disease': 'Healthy',
        'severity': 'None',
        'symptoms': 'No disease symptoms detected',
        'treatment': 'Continue regular care and monitoring',
        'prevention': 'Maintain good cultural practices'
    }
}

def get_disease_info(class_name):
    """Get detailed disease information"""
    return DISEASE_INFO.get(class_name, {
        'crop': 'Unknown',
        'disease': class_name,
        'severity': 'Unknown',
        'symptoms': 'Unable to determine',
        'treatment': 'Consult agricultural expert',
        'prevention': 'Regular monitoring recommended'
    })
