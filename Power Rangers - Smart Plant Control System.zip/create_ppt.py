"""
Convert HarioBaari presentation to PowerPoint format
Requires: pip install python-pptx requests pillow
"""

from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN
from pptx.dml.color import RGBColor
from io import BytesIO
import requests
from PIL import Image

def download_image(url):
    """Download image from URL"""
    try:
        response = requests.get(url, timeout=10)
        return BytesIO(response.content)
    except:
        return None

def add_title_slide(prs, title, subtitle):
    """Add title slide"""
    slide = prs.slides.add_slide(prs.slide_layouts[0])
    slide.shapes.title.text = title
    slide.placeholders[1].text = subtitle
    return slide

def add_content_slide(prs, title, content_items):
    """Add bullet point slide"""
    slide = prs.slides.add_slide(prs.slide_layouts[1])
    slide.shapes.title.text = title
    
    body = slide.placeholders[1].text_frame
    body.clear()
    
    for item in content_items:
        p = body.add_paragraph()
        p.text = item
        p.level = 0
        p.font.size = Pt(18)
    
    return slide

def add_two_column_slide(prs, title, left_items, right_items):
    """Add two-column slide"""
    slide = prs.slides.add_slide(prs.slide_layouts[5])  # Blank layout
    
    # Title
    title_box = slide.shapes.add_textbox(Inches(0.5), Inches(0.3), Inches(9), Inches(0.8))
    title_frame = title_box.text_frame
    title_frame.text = title
    title_frame.paragraphs[0].font.size = Pt(32)
    title_frame.paragraphs[0].font.bold = True
    title_frame.paragraphs[0].font.color.rgb = RGBColor(66, 175, 250)
    
    # Left column
    left_box = slide.shapes.add_textbox(Inches(0.5), Inches(1.3), Inches(4.5), Inches(5))
    left_frame = left_box.text_frame
    for item in left_items:
        p = left_frame.add_paragraph()
        p.text = item
        p.font.size = Pt(16)
    
    # Right column
    right_box = slide.shapes.add_textbox(Inches(5.2), Inches(1.3), Inches(4.5), Inches(5))
    right_frame = right_box.text_frame
    for item in right_items:
        p = right_frame.add_paragraph()
        p.text = item
        p.font.size = Pt(16)
    
    return slide

def create_presentation():
    """Create the full PowerPoint presentation"""
    prs = Presentation()
    prs.slide_width = Inches(10)
    prs.slide_height = Inches(7.5)
    
    # Slide 1: Title
    slide = add_title_slide(prs, 
        "🌱 HarioBaari",
        "AI-Powered Smart Greenhouse Monitoring System\n\nTeam: Power Rangers ⚡\nAayush Regmi • Bijaya Khanal • Nishchal Pokhrel • Ram Gautam"
    )
    
    # Slide 2: Project Overview
    add_content_slide(prs, "📋 Project Overview", [
        "AI-powered smart greenhouse combining IoT hardware with deep learning",
        "🌡️ Real-time environmental monitoring (temp, humidity, soil, light)",
        "⚡ Automated control of fans, pumps, and grow lights",
        "🤖 AI-based fruit/vegetable identification (36+ classes)",
        "🦠 Plant disease detection with treatment recommendations",
        "🎤 Voice-controlled interface for hands-free operation",
        "📸 Live camera feed with WebSocket streaming"
    ])
    
    # Slide 3: Problem Statement
    add_two_column_slide(prs, "🎯 Problem Statement",
        [
            "Agricultural Challenges:",
            "• Manual monitoring is time-intensive",
            "• Water wastage in irrigation",
            "• Late disease detection → crop loss",
            "• Inconsistent climate control",
            "• Limited access to expert knowledge"
        ],
        [
            "Impact:",
            "• 60% crop losses from diseases",
            "• 40% water waste from inefficient irrigation",
            "• 25-30% lower yields without optimization",
            "• High labor costs for small farmers"
        ]
    )
    
    # Slide 4: Solution
    add_content_slide(prs, "✅ Our Solution", [
        "🤖 AI Vision System: ResNet50 CNN for fruit classification & disease detection",
        "📊 Real-time Monitoring: ESP32 sensors collect data every second",
        "⚡ Automated Control: Smart thresholds trigger fans, pumps, lights",
        "🎤 Voice Commands: Hands-free operation using Web Speech API",
        "📸 Live Camera Feed: WebSocket streaming for instant inspection",
        "💊 Treatment Guidance: Disease-specific recommendations"
    ])
    
    # Slide 5: System Architecture
    add_content_slide(prs, "🏗️ System Architecture", [
        "ESP32 Sensors → Collect environmental data",
        "Flask Server → REST API + WebSocket communication",
        "ResNet50 CNN → Fruit/vegetable classification",
        "Disease Model → Plant disease detection",
        "Web Dashboard → Real-time monitoring & control",
        "Voice Interface → Hands-free commands"
    ])
    
    # Slide 6: Technologies Used
    add_two_column_slide(prs, "💻 Technologies Used",
        [
            "Hardware & Embedded:",
            "• ESP32 Microcontroller",
            "• Arduino IDE",
            "• DHT22, Soil Moisture, LDR",
            "• Relay Modules",
            "",
            "AI/ML:",
            "• PyTorch Framework",
            "• ResNet50 CNN",
            "• torchvision"
        ],
        [
            "Backend:",
            "• Flask (Python)",
            "• Flask-CORS",
            "• Flask-Sock (WebSocket)",
            "",
            "Frontend & Protocols:",
            "• HTML5/CSS3/JavaScript",
            "• Web Speech API",
            "• HTTP/HTTPS, WebSocket, JSON",
            "",
            "Datasets:",
            "• PlantVillage (Disease)",
            "• Kaggle Fruits/Vegetables"
        ]
    )
    
    # Slide 7: AI Model - Fruit Detection
    add_content_slide(prs, "🍎 AI Model: Fruit/Vegetable Detection", [
        "ResNet50 CNN Architecture:",
        "• Pre-trained on ImageNet, fine-tuned for 36+ produce classes",
        "• Heavy data augmentation (color jitter, crops, flips)",
        "• AdamW optimizer with cosine annealing scheduler",
        "• Label smoothing (0.1) to prevent overfitting",
        "• Test-time augmentation with 4 strategies",
        "• Ensemble predictions with color-based boosting",
        "• Accuracy: ~85% on validation set"
    ])
    
    # Slide 8: Disease Detection
    add_content_slide(prs, "🦠 Disease Detection System", [
        "Plant Disease CNN (PlantVillage Dataset):",
        "• 38 plant diseases across multiple crops",
        "• Convolutional layers learn leaf patterns (spots, lesions, discoloration)",
        "• Deeper layers detect disease-specific signatures",
        "• Output: Disease name, confidence, crop type",
        "• Provides symptoms, causes, treatment, prevention",
        "• Preprocessing: Resize → 224×224 crop → ImageNet normalization"
    ])
    
    # Slide 9: Hardware Components
    add_two_column_slide(prs, "🔌 Hardware Components",
        [
            "Microcontrollers:",
            "• ESP32 Dev Board (Sensor Node)",
            "• ESP32-CAM Module",
            "",
            "Sensors:",
            "• DHT22 (Temp & Humidity)",
            "• Soil Moisture Sensor",
            "• LDR (Light Sensor)"
        ],
        [
            "Actuators:",
            "• 3-Channel Relay Module",
            "• DC Fan (12V)",
            "• Water Pump (5V/12V)",
            "• LED Grow Light",
            "",
            "Power & Connectivity:",
            "• 5V/12V Power Supply",
            "• Jumper Wires & Breadboard",
            "• USB Cable"
        ]
    )
    
    # Slide 10: Key Features
    add_content_slide(prs, "🌟 Key Features", [
        "✅ Real-time Monitoring: Sensor data updated every second",
        "✅ Automated Control: Threshold-based automation",
        "✅ AI Vision: Instant fruit/vegetable identification (85% accuracy)",
        "✅ Disease Diagnosis: Early detection with treatment plans",
        "✅ Voice Interface: Hands-free commands via Web Speech API",
        "✅ Live Camera: Real-time streaming via WebSocket (10fps)",
        "✅ Web Dashboard: Responsive interface with charts",
        "✅ Fun Facts: Educational info about detected produce"
    ])
    
    # Slide 11: Challenges & Solutions
    add_content_slide(prs, "🚧 Challenges & Solutions", [
        "❌ Low model accuracy (65%) → ✅ Upgraded to ResNet50 + TTA → 85%",
        "❌ WebSocket disconnections → ✅ Binary transmission + auto-reconnect",
        "❌ Class count mismatch → ✅ Dynamic class detection from FC layer",
        "❌ Voice API failed on HTTP → ✅ Localhost exception + fallback",
        "❌ Slow inference (3-5s) → ✅ Pre-loaded models + cached pipelines"
    ])
    
    # Slide 12: Practical Impact
    add_two_column_slide(prs, "🌍 Practical Impact",
        [
            "Resource Optimization:",
            "• 40% water savings",
            "• Smart irrigation",
            "• Energy-efficient climate control",
            "",
            "Yield Improvement:",
            "• 25-30% higher yields",
            "• Early disease detection",
            "• Optimal growing conditions"
        ],
        [
            "Business Potential:",
            "• Affordable (<$100 per unit)",
            "• Scalable architecture",
            "• Accessible to small farmers",
            "",
            "Social Impact:",
            "• Food security",
            "• Reduced pesticide use",
            "• Climate resilience",
            "• Accessible to elderly/non-tech users"
        ]
    )
    
    # Slide 13: Results & Performance
    add_content_slide(prs, "📊 Results & Performance", [
        "🎯 Fruit Detection Accuracy: 85% on 36+ classes",
        "🦠 Disease Detection: 38 disease classes with treatment info",
        "⚡ Inference Speed: <1.5s per prediction (optimized)",
        "📹 Camera Stream: Stable 10fps at QVGA resolution",
        "📡 Sensor Response: Real-time updates every 1-2 seconds",
        "🎤 Voice Recognition: 90%+ accuracy in quiet environments",
        "💾 Model Size: ~100MB (ResNet50 + Disease Model)",
        "🔋 Power Consumption: <15W total system"
    ])
    
    # Slide 14: Future Enhancements
    add_content_slide(prs, "🚀 Future Enhancements", [
        "🌐 Cloud Integration: Remote monitoring via mobile app",
        "📱 Mobile App: Cross-platform Flutter/React Native app",
        "📊 Advanced Analytics: Growth prediction, yield forecasting",
        "🤖 Reinforcement Learning: Adaptive threshold tuning",
        "🔬 Multi-Crop Support: Specialized models for different crops",
        "🌡️ Additional Sensors: CO₂, pH, nutrient levels",
        "💬 Notifications: SMS/Email alerts for critical conditions",
        "⚡ Solar Power: Off-grid operation for rural areas"
    ])
    
    # Slide 15: Team Members
    slide = prs.slides.add_slide(prs.slide_layouts[5])
    
    # Title
    title_box = slide.shapes.add_textbox(Inches(2), Inches(0.3), Inches(6), Inches(0.8))
    title_frame = title_box.text_frame
    title_frame.text = "👥 Team Power Rangers ⚡"
    title_frame.paragraphs[0].font.size = Pt(36)
    title_frame.paragraphs[0].font.bold = True
    title_frame.paragraphs[0].alignment = PP_ALIGN.CENTER
    title_frame.paragraphs[0].font.color.rgb = RGBColor(74, 222, 128)
    
    # Team members - 2x2 grid
    members = [
        ("🔴 Aayush Regmi", "AI/ML & Backend Development"),
        ("🔵 Bijaya Khanal", "Hardware & IoT Integration"),
        ("🟡 Nishchal Pokhrel", "Frontend & UI/UX Design"),
        ("🟢 Ram Gautam", "System Architecture & Testing")
    ]
    
    positions = [
        (1, 1.8), (5.5, 1.8),
        (1, 4.2), (5.5, 4.2)
    ]
    
    for i, (member, role) in enumerate(members):
        x, y = positions[i]
        box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(4), Inches(1.8))
        frame = box.text_frame
        
        # Member name
        p1 = frame.add_paragraph()
        p1.text = member
        p1.font.size = Pt(20)
        p1.font.bold = True
        p1.alignment = PP_ALIGN.CENTER
        p1.font.color.rgb = RGBColor(66, 175, 250)
        
        # Role
        p2 = frame.add_paragraph()
        p2.text = role
        p2.font.size = Pt(14)
        p2.alignment = PP_ALIGN.CENTER
        p2.font.color.rgb = RGBColor(200, 200, 200)
    
    # Subtitle
    subtitle_box = slide.shapes.add_textbox(Inches(2), Inches(6.5), Inches(6), Inches(0.5))
    subtitle_frame = subtitle_box.text_frame
    subtitle_frame.text = "Together, we build the future of smart agriculture! 🚀"
    subtitle_frame.paragraphs[0].font.size = Pt(18)
    subtitle_frame.paragraphs[0].alignment = PP_ALIGN.CENTER
    subtitle_frame.paragraphs[0].font.color.rgb = RGBColor(74, 222, 128)
    
    # Slide 16: Conclusion
    add_content_slide(prs, "🎉 Conclusion", [
        "HarioBaari demonstrates how AI + IoT can revolutionize agriculture",
        "",
        "✅ Practical solution for real-world farming challenges",
        "✅ Affordable and accessible technology (<$100)",
        "✅ Significant impact on yield, water usage, sustainability",
        "✅ Educational demonstration of ML, transfer learning, IoT",
        "✅ Scalable from home gardens to commercial farms",
        "",
        "🌱 Empowering farmers through intelligent automation! 🚀"
    ])
    
    # Slide 17: Thank You
    slide = add_title_slide(prs, 
        "Thank You! 🙏",
        "Team Power Rangers\n\nAayush • Bijaya • Nishchal • Ram\n\nLive Demo: http://localhost:5000\n\n🌱 Let's grow together! 🚀"
    )
    
    return prs

if __name__ == "__main__":
    print("Creating PowerPoint presentation...")
    print("This may take a moment...")
    
    try:
        prs = create_presentation()
        output_file = "HarioBaari_Presentation.pptx"
        prs.save(output_file)
        print(f"\n✅ Success! Presentation saved as: {output_file}")
        print(f"📊 Total slides: {len(prs.slides)}")
        print("\nYou can now open this file in PowerPoint, Google Slides, or LibreOffice!")
    except Exception as e:
        print(f"\n❌ Error creating presentation: {e}")
        print("\nMake sure you have installed: pip install python-pptx")
