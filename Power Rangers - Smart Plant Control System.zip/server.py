# server.py - Complete Plant Monitor Server with Fruit/Vegetable Detection
from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
from flask_sock import Sock
from datetime import datetime
import json
import os
import base64
import threading
import time
import sys
import shutil
import subprocess
import webbrowser
from io import BytesIO
from PIL import Image
import argparse

# Import our fruit/vegetable detector
try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    from torchvision import transforms, models
    import torchvision
    TORCH_AVAILABLE = True
    # Import disease detection model
    from disease_model import PlantDiseaseModel, DISEASE_CLASSES, get_disease_info
except Exception as e:
    print(f"PyTorch not available: {e}")
    TORCH_AVAILABLE = False

app = Flask(__name__)
CORS(app)
sock = Sock(app)

# ========================================
# FRUIT/VEGETABLE DETECTOR CLASS
# ========================================

class FruitVegetableDetector:
    def __init__(self, model_path=None, class_mapping_path=None, device=None):
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.model = None
        self.classes = []
        self.model_type = "resnet50"  # Better accuracy than ResNet18
        
        # Load class mapping
        if class_mapping_path and os.path.exists(class_mapping_path):
            with open(class_mapping_path, 'r') as f:
                self.classes = json.load(f)
        else:
            # Default classes
            self.classes = [
                'apple', 'banana', 'beetroot', 'bell pepper', 'cabbage', 
                'capsicum', 'carrot', 'cauliflower', 'chilli pepper', 'corn', 
                'cucumber', 'eggplant', 'garlic', 'ginger', 'grapes', 
                'jalapeno', 'kiwi', 'lemon', 'lettuce', 'mango', 
                'onion', 'orange', 'paprika', 'pear', 'peas', 
                'pineapple', 'pomegranate', 'potato', 'radish', 'soy beans', 
                'spinach', 'sweetcorn', 'sweet potato', 'tomato', 'turnip', 'watermelon'
            ]
        
        # Color-based characteristics for fallback detection
        self.color_ranges = {
            'apple': {'r': 180, 'g': 50, 'b': 50, 'description': 'reddish'},
            'banana': {'r': 220, 'g': 200, 'b': 40, 'description': 'yellowish'},
            'orange': {'r': 220, 'g': 130, 'b': 30, 'description': 'orange'},
            'lemon': {'r': 230, 'g': 220, 'b': 50, 'description': 'yellow'},
            'tomato': {'r': 200, 'g': 50, 'b': 40, 'description': 'red'},
            'carrot': {'r': 210, 'g': 120, 'b': 20, 'description': 'orange'},
            'pumpkin': {'r': 210, 'g': 130, 'b': 30, 'description': 'orange'},
            'grape': {'r': 100, 'g': 70, 'b': 120, 'description': 'purple'},
            'watermelon': {'r': 100, 'g': 150, 'b': 80, 'description': 'greenish'},
            'kiwi': {'r': 100, 'g': 150, 'b': 80, 'description': 'greenish'},
            'spinach': {'r': 80, 'g': 120, 'b': 60, 'description': 'dark green'},
            'broccoli': {'r': 70, 'g': 130, 'b': 60, 'description': 'green'},
        }
        
        # Valid fruits and vegetables (everything in self.classes is valid)
        self.valid_items = set([
            'apple', 'banana', 'beetroot', 'bell pepper', 'cabbage', 
            'capsicum', 'carrot', 'cauliflower', 'chilli pepper', 'corn', 
            'cucumber', 'eggplant', 'garlic', 'ginger', 'grapes', 
            'jalapeno', 'kiwi', 'lemon', 'lettuce', 'mango', 
            'onion', 'orange', 'paprika', 'pear', 'peas', 
            'pineapple', 'pomegranate', 'potato', 'radish', 'soy beans', 
            'spinach', 'sweetcorn', 'sweet potato', 'tomato', 'turnip', 'watermelon',
            'broccoli', 'grape', 'pumpkin'  # Additional valid items
        ])
        
        # Enhanced image transformations for better accuracy
        self.transform = transforms.Compose([
            transforms.Resize((400, 400)),  # Larger intermediate size
            transforms.CenterCrop(384),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                               std=[0.229, 0.224, 0.225]),
            # Additional regularization
            transforms.RandomErasing(p=0.0)  # No erasing at inference
        ])
        
        # For ensemble predictions - different crop strategy
        self.transform_alt = transforms.Compose([
            transforms.Resize((420, 420)),
            transforms.RandomCrop(384, pad_if_needed=True),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                               std=[0.229, 0.224, 0.225])
        ])

        # Load model
        if model_path and os.path.exists(model_path) and TORCH_AVAILABLE:
            print(f"Loading model from {model_path}")
            self.load_model(model_path)
        elif TORCH_AVAILABLE:
            print("Creating new model with pre-trained weights...")
            self.create_model()
        
        if self.model and TORCH_AVAILABLE:
            self.model.eval()
            self.model.to(self.device)
            print(f"[OK] Model loaded on {self.device}")
        else:
            print("[WARNING] Using hybrid detection (neural + color-based fallback)")
    
    def create_model(self):
        """Create a ResNet50 model for fruit/vegetable classification with better accuracy"""
        try:
            # Use ResNet50 which has better accuracy than ResNet18
            # ResNet50 provides 76.13% ImageNet accuracy vs 71.3% for ResNet18
            try:
                self.model = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V1)
            except:
                # Fallback to using pretrained parameter name
                self.model = models.resnet50(pretrained=True)
            
            num_features = self.model.fc.in_features
            self.model.fc = nn.Linear(num_features, len(self.classes))
            
            # Freeze early layers for better transfer learning
            for param in list(self.model.parameters())[:-20]:
                param.requires_grad = False
            
            print(f"[OK] Created ResNet50 model with {len(self.classes)} classes")
        except Exception as e:
            print(f"Error creating model: {e}")
            self.model = None
    
    def load_model(self, model_path):
        """Load a trained model (ResNet50)"""
        try:
            # Use ResNet50 architecture
            try:
                self.model = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V1)
            except:
                self.model = models.resnet50(pretrained=True)
            
            num_features = self.model.fc.in_features
            self.model.fc = nn.Linear(num_features, len(self.classes))
            
            state_dict = torch.load(model_path, map_location=self.device)
            self.model.load_state_dict(state_dict, strict=False)
            print(f"Model loaded successfully (ResNet50) with {len(self.classes)} classes")
        except Exception as e:
            print(f"Error loading model: {e}")
            self.create_model()
    
    def _load_image(self, image_input):
        """Load image from various input types with enhanced preprocessing"""
        try:
            if isinstance(image_input, BytesIO):
                image_input.seek(0)
                img = Image.open(image_input).convert('RGB')
            elif isinstance(image_input, Image.Image):
                img = image_input.convert('RGB')
            elif isinstance(image_input, bytes):
                img = Image.open(BytesIO(image_input)).convert('RGB')
            elif isinstance(image_input, str):
                # Assume it's a file path
                img = Image.open(image_input).convert('RGB')
            else:
                raise ValueError(f"Unsupported image input type: {type(image_input)}")
            
            # Enhance image contrast and sharpness for better feature detection
            try:
                from PIL import ImageEnhance
                # Enhance contrast to make fruit/vegetable features more distinct
                enhancer = ImageEnhance.Contrast(img)
                img = enhancer.enhance(1.2)  # Slight contrast boost
                
                # Enhance sharpness to highlight details
                enhancer = ImageEnhance.Sharpness(img)
                img = enhancer.enhance(1.1)  # Slight sharpness boost
                
                # Enhance color saturation to highlight natural colors
                enhancer = ImageEnhance.Color(img)
                img = enhancer.enhance(1.15)  # Boost color saturation
            except:
                pass  # Continue without enhancement if it fails
            
            return img
        except Exception as e:
            print(f"Error loading image: {e}")
            return None
    
    def predict(self, image_input, top_k=3):
        """Predict fruit/vegetable from image with advanced inference techniques for better accuracy"""
        if self.model is None or not TORCH_AVAILABLE:
            return [{"label": "unknown", "confidence": 0.0}]
        
        try:
            img = self._load_image(image_input)
            if img is None:
                return [{"label": "error", "confidence": 0.0}]
            
            # Advanced Test-Time Augmentation (TTA) with multiple crops and flips
            logits_list = []
            
            # Strategy 1: Center crop (primary)
            input_tensor1 = self.transform(img).unsqueeze(0).to(self.device)
            with torch.no_grad():
                outputs1 = self.model(input_tensor1)
                logits_list.append(outputs1)
            
            # Strategy 2: Alternative crop
            input_tensor2 = self.transform_alt(img).unsqueeze(0).to(self.device)
            with torch.no_grad():
                outputs2 = self.model(input_tensor2)
                logits_list.append(outputs2)
            
            # Strategy 3: Horizontally flipped image (crops often miss details)
            img_flipped = transforms.functional.hflip(img)
            input_tensor3 = self.transform(img_flipped).unsqueeze(0).to(self.device)
            with torch.no_grad():
                outputs3 = self.model(input_tensor3)
                logits_list.append(outputs3)
            
            # Strategy 4: Slightly zoomed in (focuses on fruit details)
            try:
                img_zoomed = transforms.functional.center_crop(img, (int(img.height*0.8), int(img.width*0.8)))
                img_zoomed = img_zoomed.resize((384, 384), Image.Resampling.LANCZOS)
                input_tensor4 = self.transform(img_zoomed).unsqueeze(0).to(self.device)
                with torch.no_grad():
                    outputs4 = self.model(input_tensor4)
                    logits_list.append(outputs4)
            except:
                pass  # Skip if zoom fails
            
            # Ensemble logits and convert once to probabilities to avoid double-softmax flattening confidences
            ensemble_logits = torch.stack(logits_list, dim=0).mean(dim=0)
            
            # Apply temperature scaling for better calibration (more confident)
            temperature = 1.0  # Lower temperature gives sharper (higher) confidences; 1.0 keeps model-native scale
            ensemble_probs = F.softmax(ensemble_logits / temperature, dim=1)
            
            # Get top-k predictions
            top_probs, top_indices = ensemble_probs.topk(min(top_k, len(self.classes)), dim=1)
            
            # Calculate prediction entropy (uncertainty measure)
            # High entropy = model is uncertain, low entropy = model is confident
            import math
            probs_np = ensemble_probs[0].cpu().numpy()
            entropy = -sum([float(p) * math.log(float(p) + 1e-10) for p in probs_np if float(p) > 0])
            max_entropy = math.log(len(self.classes))
            normalized_entropy = float(entropy / max_entropy)  # 0 = certain, 1 = maximum uncertainty
            
            results = []
            for i in range(top_probs.shape[1]):
                idx = int(top_indices[0, i].item())
                conf = float(top_probs[0, i].item())
                
                if idx < len(self.classes):
                    label = self.classes[idx]
                else:
                    label = f"class_{idx}"
                
                # Confidence calibration: slightly boost strong signals, keep lows unchanged
                if conf > 0.7:
                    conf = min(0.98, conf * 1.08)
                
                results.append({
                    "label": label,
                    "confidence": round(conf, 4),
                    "index": idx
                })
            
            # Add metadata for validation
            if len(results) >= 2:
                results[0]['margin'] = results[0]['confidence'] - results[1]['confidence']
            else:
                results[0]['margin'] = results[0]['confidence']
            
            results[0]['entropy'] = round(normalized_entropy, 4)
            
            # Apply color-based boosting for better accuracy
            results = self._boost_by_color(results, img)
            
            return results
            
        except Exception as e:
            print(f"Prediction error: {e}")
            return [{"label": "error", "confidence": 0.0}]
    
    def _detect_color_characteristics(self, img):
        """Extract dominant colors for fallback detection"""
        try:
            import numpy as np
            from PIL import ImageOps
            
            # Resize image for faster color analysis
            img_small = img.resize((100, 100))
            
            # Get dominant colors in different regions
            pixels = np.array(img_small)
            
            # Sample center and corners
            h, w = pixels.shape[:2]
            samples = [
                pixels[h//4:3*h//4, w//4:3*w//4, :],  # Center
                pixels[:h//3, :w//3, :],  # Top-left
                pixels[2*h//3:, 2*w//3:, :],  # Bottom-right
            ]
            
            # Calculate average color from samples
            avg_r = int(np.mean([s[:,:,0].mean() for s in samples]))
            avg_g = int(np.mean([s[:,:,1].mean() for s in samples]))
            avg_b = int(np.mean([s[:,:,2].mean() for s in samples]))
            
            return avg_r, avg_g, avg_b
        except:
            return None, None, None
    
    def _boost_by_color(self, results, img):
        """Boost prediction confidence based on color analysis"""
        try:
            r, g, b = self._detect_color_characteristics(img)
            if r is None:
                return results
            
            # Boost confidence for color-matching predictions
            for result in results:
                label = result['label'].lower()
                
                # Color-based boosting logic
                if label in ['apple', 'pomegranate', 'tomato'] and r > 150 and r > g and r > b:
                    result['confidence'] = min(0.99, result['confidence'] * 1.3)
                elif label in ['banana', 'lemon', 'pineapple'] and g > 150 and r > b:
                    result['confidence'] = min(0.99, result['confidence'] * 1.3)
                elif label in ['orange', 'carrot', 'mango'] and r > 180 and g > 100 and b < 100:
                    result['confidence'] = min(0.99, result['confidence'] * 1.3)
                elif label in ['grape', 'blueberry'] and b > 100 and r < 150:
                    result['confidence'] = min(0.99, result['confidence'] * 1.2)
                elif label in ['watermelon', 'kiwi', 'spinach'] and g > r and g > b:
                    result['confidence'] = min(0.99, result['confidence'] * 1.2)
                elif label in ['potato', 'onion', 'garlic'] and 50 < r < 150 and r-g < 50:
                    result['confidence'] = min(0.99, result['confidence'] * 1.15)
            
            return sorted(results, key=lambda x: x['confidence'], reverse=True)
        except:
            return results
    
    def is_valid_fruit_vegetable(self, result, threshold=0.35):
        """Check if detected object is a valid fruit or vegetable with enhanced validation
        
        Args:
            result: Detection result dictionary with label, confidence, entropy, margin
            threshold: Minimum confidence to accept detection (default 0.35)
            
        Returns:
            tuple: (is_valid: bool, error_message: str or None)
        """
        label = result.get('label', '')
        confidence = result.get('confidence', 0.0)
        entropy = result.get('entropy', 0.0)
        margin = result.get('margin', 0.0)
        
        # If confidence is very low, we can't be sure what it is
        if confidence < 0.05:
            return True, None  # Let low confidence handler deal with it
        
        # Check if the label is in our valid list
        label_lower = label.lower().strip()
        is_in_valid_list = False
        
        # Check exact match
        if label_lower in self.valid_items:
            is_in_valid_list = True
        else:
            # Check if any valid item is part of the label
            for valid_item in self.valid_items:
                if valid_item in label_lower or label_lower in valid_item:
                    is_in_valid_list = True
                    break
        
        # If not in valid list at all, reject
        if not is_in_valid_list:
            if confidence >= 0.3:
                return False, f"Detected object '{label}' is not a fruit or vegetable. Please upload an image of fruits or vegetables only."
            return False, f"Unable to identify a clear fruit or vegetable in the image. Please upload a clear image of fruits or vegetables."
        
        # Enhanced validation: Even if label is valid, check if model is actually confident
        # High entropy (>0.65) means model is very uncertain - likely misclassifying
        if entropy > 0.65:
            return False, f"Unable to clearly identify the object as {label}. The image may not contain fruits or vegetables. Please ensure you're showing actual produce to the camera."
        
        # Medium-high entropy (>0.55) with low-medium confidence - likely misclassification
        if entropy > 0.55 and confidence < 0.7:
            return False, f"Uncertain detection of '{label}'. This does not appear to be a clear fruit or vegetable. Please show actual produce to the camera."
        
        # Low confidence but in valid list - likely misclassification
        if confidence < threshold:
            return False, f"Not a clear fruit or vegetable. Detected '{label}' with {confidence*100:.1f}% confidence. Please show actual fruits or vegetables to the camera."
        
        # Small margin between top predictions - model is confused
        if margin < 0.2 and confidence < 0.75:
            return False, f"Uncertain detection. The object does not appear to be a clear fruit or vegetable. Please ensure actual produce is visible in the image."
        
        # All checks passed
        return True, None
    
    def predict_pil(self, image_input):
        """Backward compatibility method"""
        results = self.predict(image_input, top_k=1)
        if results:
            return results[0]["label"], results[0]["confidence"]
        return "unknown", 0.0
    
    def get_fun_fact(self, label):
        """Get interesting facts about fruits/vegetables"""
        facts = {
            'apple': {
                'fact': 'Apples float because 25% of their volume is air!',
                'benefit': 'Rich in fiber and antioxidants'
            },
            'banana': {
                'fact': 'Bananas are berries, but strawberries are not!',
                'benefit': 'High in potassium and natural energy'
            },
            'tomato': {
                'fact': 'Tomatoes are technically a fruit, not a vegetable!',
                'benefit': 'Excellent source of lycopene and vitamin C'
            },
            'carrot': {
                'fact': 'Carrots were originally purple, not orange!',
                'benefit': 'Great for eye health with vitamin A'
            },
            'orange': {
                'fact': 'Oranges are a hybrid of pomelo and mandarin!',
                'benefit': 'Packed with vitamin C and fiber'
            },
            'strawberry': {
                'fact': 'Strawberries are the only fruit with seeds on the outside!',
                'benefit': 'High in vitamin C and antioxidants'
            },
            'grape': {
                'fact': 'It takes about 600 grapes to make one bottle of wine!',
                'benefit': 'Rich in antioxidants and vitamin K'
            },
            'watermelon': {
                'fact': 'Watermelon is 92% water!',
                'benefit': 'Great for hydration and contains lycopene'
            },
            'pineapple': {
                'fact': 'Pineapple is actually a cluster of berries fused together!',
                'benefit': 'Contains bromelain which helps digestion'
            },
            'mango': {
                'fact': 'Mangoes are the most consumed fruit in the world!',
                'benefit': 'Rich in vitamins A and C'
            }
        }
        
        label_lower = label.lower()
        for key in facts:
            if key in label_lower:
                return facts[key]
        
        return {
            'fact': 'This is a healthy choice! Fresh produce is good for you.',
            'benefit': 'Provides essential vitamins and minerals'
        }
    
    def train(self, dataset_path, epochs=25, save_path='fruit_veg_model.pth', batch_size=32, num_workers=4, lr=0.0001):
        """Train the model on fruit/vegetable dataset with improved accuracy"""
        if not TORCH_AVAILABLE:
            print("PyTorch not available for training")
            return
        
        print(f"Training model on {dataset_path}...")
        
        try:
            # Enhanced data transformations with stronger augmentation
            train_transform = transforms.Compose([
                transforms.RandomResizedCrop(384, scale=(0.8, 1.0)),
                transforms.RandomHorizontalFlip(p=0.5),
                transforms.RandomVerticalFlip(p=0.2),
                transforms.RandomRotation(20),
                transforms.ColorJitter(brightness=0.3, contrast=0.3, saturation=0.3, hue=0.1),
                transforms.RandomAffine(degrees=0, translate=(0.1, 0.1)),
                transforms.GaussianBlur(kernel_size=3),
                transforms.ToTensor(),
                transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                   std=[0.229, 0.224, 0.225])
            ])
            
            val_transform = transforms.Compose([
                transforms.Resize(400),
                transforms.CenterCrop(384),
                transforms.ToTensor(),
                transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                   std=[0.229, 0.224, 0.225])
            ])
            
            # Load datasets
            train_dataset = torchvision.datasets.ImageFolder(
                root=os.path.join(dataset_path, 'train'),
                transform=train_transform
            )
            
            val_dataset = torchvision.datasets.ImageFolder(
                root=os.path.join(dataset_path, 'test'),
                transform=val_transform
            )
            
            # Get class names
            self.classes = train_dataset.classes
            print(f"Found {len(self.classes)} classes: {self.classes}")
            
            # Save class mapping
            with open('models/class_mapping.json', 'w') as f:
                json.dump(self.classes, f)
            
            # Create data loaders; batch size adjustable for GPU memory
            train_loader = torch.utils.data.DataLoader(
                train_dataset,
                batch_size=batch_size,
                shuffle=True,
                num_workers=num_workers,
                pin_memory=True
            )
            
            val_loader = torch.utils.data.DataLoader(
                val_dataset,
                batch_size=batch_size,
                shuffle=False,
                num_workers=num_workers,
                pin_memory=True
            )
            
            # Update model for correct number of classes
            if hasattr(self.model, 'classifier'):
                # EfficientNet
                num_features = self.model.classifier[1].in_features
                self.model.classifier[1] = nn.Linear(num_features, len(self.classes))
            else:
                # ResNet
                num_features = self.model.fc.in_features
                self.model.fc = nn.Linear(num_features, len(self.classes))
            
            self.model.to(self.device)
            
            # Loss and optimizer with label smoothing
            criterion = nn.CrossEntropyLoss(label_smoothing=0.1)
            
            # Use AdamW optimizer with weight decay for better generalization
            optimizer = torch.optim.AdamW(
                [p for p in self.model.parameters() if p.requires_grad],
                lr=lr,
                weight_decay=0.01
            )
            
            # Use cosine annealing scheduler for better convergence
            scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs, eta_min=0.00001)
            
            # Training loop
            best_accuracy = 0.0
            
            for epoch in range(epochs):
                print(f"\nEpoch {epoch+1}/{epochs}")
                print("-" * 50)
                
                # Training phase
                self.model.train()
                running_loss = 0.0
                running_corrects = 0
                
                for inputs, labels in train_loader:
                    inputs, labels = inputs.to(self.device), labels.to(self.device)
                    
                    optimizer.zero_grad()
                    outputs = self.model(inputs)
                    loss = criterion(outputs, labels)
                    _, preds = torch.max(outputs, 1)
                    
                    loss.backward()
                    optimizer.step()
                    
                    running_loss += loss.item() * inputs.size(0)
                    running_corrects += torch.sum(preds == labels.data)
                
                epoch_loss = running_loss / len(train_dataset)
                epoch_acc = running_corrects.double() / len(train_dataset)
                
                print(f"Train Loss: {epoch_loss:.4f} Acc: {epoch_acc:.4f}")
                
                # Validation phase
                self.model.eval()
                val_loss = 0.0
                val_corrects = 0
                
                with torch.no_grad():
                    for inputs, labels in val_loader:
                        inputs, labels = inputs.to(self.device), labels.to(self.device)
                        outputs = self.model(inputs)
                        loss = criterion(outputs, labels)
                        _, preds = torch.max(outputs, 1)
                        
                        val_loss += loss.item() * inputs.size(0)
                        val_corrects += torch.sum(preds == labels.data)
                
                val_loss = val_loss / len(val_dataset)
                val_acc = val_corrects.double() / len(val_dataset)
                
                print(f"Val Loss: {val_loss:.4f} Acc: {val_acc:.4f}")
                
                # Save best model
                if val_acc > best_accuracy:
                    best_accuracy = val_acc
                    torch.save(self.model.state_dict(), save_path)
                    print(f"💾 Saved best model with accuracy: {best_accuracy:.4f}")
                
                scheduler.step()
            
            print(f"\n🎉 Training completed! Best accuracy: {best_accuracy:.4f}")
            print(f"Model saved to {save_path}")
            
        except Exception as e:
            print(f"Training error: {e}")
            import traceback
            traceback.print_exc()

# ========================================
# SERVER CONFIGURATION
# ========================================

def download_pretrained_model():
    """Download pre-trained model from Kaggle or create sample model"""
    model_path = 'models/fruit_veg_model.pth'
    
    if os.path.exists(model_path):
        print(f"[OK] Model already exists at {model_path}")
        return True
    
    print("[INFO] Pre-trained model not found. Attempting to download...")
    
    # Check if dataset exists
    dataset_path = 'datasets/fruits_vegetables/train'
    has_dataset = os.path.exists(dataset_path) and len(os.listdir(dataset_path)) > 0
    
    if not has_dataset:
        print("\n" + "="*60)
        print("[INFO] Dataset not found!")
        print("="*60)
        print("To train an accurate model, you need to:")
        print("1. Download dataset: python dataset.py")
        print("2. Train the model: python train-model.py")
        print("3. Restart server: python server.py")
        print("="*60)
        print("\nFor now, creating a model with ImageNet transfer learning...")
        print("(Will have limited accuracy until trained)\n")
    
    try:
        # Try importing dataset.py functions
        from dataset import create_sample_model
        
        # Create models directory
        os.makedirs('models', exist_ok=True)
        
        print("[INFO] Creating pre-trained model with ImageNet weights...")
        create_sample_model()
        
        if os.path.exists(model_path):
            print("[OK] Model successfully created!")
            if not has_dataset:
                print("[WARNING] This model is NOT trained on fruits/vegetables yet")
                print("[WARNING] Run 'python train-model.py' for accurate predictions")
            return True
        else:
            print("[WARNING] Model creation completed but file not found")
            return False
            
    except Exception as e:
        print(f"[WARNING] Could not download/create model: {e}")
        print("[INFO] Server will use untrained ResNet50 backbone")
        return False

# Create detector instance
if TORCH_AVAILABLE:
    try:
        # Download model if needed
        download_pretrained_model()
        
        # Try to load the trained model
        model_path = 'models/fruit_veg_model.pth'
        class_mapping_path = 'models/class_mapping.json'
        
        if not os.path.exists(model_path):
            # Try sample model
            model_path = 'models/sample_model.pth'
        
        detector = FruitVegetableDetector(
            model_path=model_path if os.path.exists(model_path) else None,
            class_mapping_path=class_mapping_path
        )
        DETECTOR_AVAILABLE = True
        print("[OK] Fruit/Vegetable detector initialized successfully")
        
    except Exception as e:
        print(f"Error initializing detector: {e}")
        detector = None
        DETECTOR_AVAILABLE = False
else:
    print("[WARNING] PyTorch not available. Using dummy detector.")
    detector = None
    DETECTOR_AVAILABLE = False

# Create disease detector instance
disease_detector = None
DISEASE_DETECTOR_AVAILABLE = False

if TORCH_AVAILABLE:
    try:
        disease_model_path = 'models/disease_model.pth'
        
        if os.path.exists(disease_model_path):
            print("Loading disease detection model...")
            checkpoint = torch.load(disease_model_path, map_location='cpu')
            
            # Determine number of classes from checkpoint
            if isinstance(checkpoint, dict) and 'model_state_dict' in checkpoint:
                checkpoint_state = checkpoint['model_state_dict']
            else:
                checkpoint_state = checkpoint
            
            # Get num_classes from checkpoint FC layer weight shape
            fc_weight_shape = None
            for key, val in checkpoint_state.items():
                if 'fc.weight' in key:
                    fc_weight_shape = val.shape
                    break
            
            # Determine number of classes
            if fc_weight_shape:
                num_classes = fc_weight_shape[0]
                print(f"[INFO] Detected {num_classes} classes from checkpoint")
            else:
                num_classes = len(DISEASE_CLASSES)
                print(f"[INFO] Using default {num_classes} classes")
            
            # Create model with correct number of classes
            disease_detector_model = PlantDiseaseModel(num_classes=num_classes)
            
            # Load checkpoint with strict=False to handle mismatches
            try:
                if isinstance(checkpoint, dict) and 'model_state_dict' in checkpoint:
                    disease_detector_model.load_state_dict(checkpoint['model_state_dict'], strict=False)
                else:
                    disease_detector_model.load_state_dict(checkpoint, strict=False)
            except Exception as load_err:
                print(f"[WARNING] Strict loading failed, trying flexible load: {load_err}")
                disease_detector_model.load_state_dict(checkpoint_state if 'checkpoint_state' in locals() else checkpoint, strict=False)
            
            disease_detector_model.eval()
            disease_detector_model.to('cpu')
            
            # Disease detection transform
            disease_transform = transforms.Compose([
                transforms.Resize((256, 256)),
                transforms.CenterCrop(224),
                transforms.ToTensor(),
                transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                   std=[0.229, 0.224, 0.225])
            ])
            
            # Use appropriate disease classes based on model
            if num_classes == 38:
                disease_classes = DISEASE_CLASSES
            elif num_classes == 15:
                # Use subset of diseases if model has 15 classes
                disease_classes = DISEASE_CLASSES[:15]
                print(f"[INFO] Using {num_classes} disease classes")
            else:
                disease_classes = [f"Disease_{i}" for i in range(num_classes)]
                print(f"[INFO] Using {num_classes} generic disease classes")
            
            disease_detector = {
                'model': disease_detector_model,
                'transform': disease_transform,
                'classes': disease_classes,
                'num_classes': num_classes
            }
            DISEASE_DETECTOR_AVAILABLE = True
            print("[OK] Disease detector initialized successfully")
            print(f"[OK] Disease model has {num_classes} classes")
        else:
            print(f"[INFO] Disease model not found at {disease_model_path}")
            print("[INFO] Run 'python train_disease_model.py' to train disease detection")
            DISEASE_DETECTOR_AVAILABLE = False
    except Exception as e:
        print(f"Error initializing disease detector: {e}")
        import traceback
        traceback.print_exc()
        disease_detector = None
        DISEASE_DETECTOR_AVAILABLE = False

# Storage for sensor data and commands
sensor_data_store = {
    'sensor_node_1': {
        'temperature': 24.5,
        'humidity': 65.0,
        'soil_moisture': 60,
        'light_intensity': 0,
        'fan_state': False,
        'pump_state': False,
        'bulb_state': False,
        'last_updated': None
    }
}

# Command storage
command_store = {
    'sensor_node_1': {
        'fan_manual': False,
        'fan_state': False,
        'pump_manual': False,
        'pump_state': False,
        'bulb_manual': False,
        'bulb_state': False,
        'server_ip': '10.206.250.110'
    }
}

# Latest detection storage
latest_detection = {
    'fruit_name': None,
    'confidence': 0,
    'timestamp': None,
    'disease': None,
    'disease_confidence': 0,
    'disease_details': None
}

# Camera feed storage
camera_store = {
    'latest_frame': None,
    'frame_count': 0,
    'last_timestamp': None,
    'device_id': None,
    'streaming': False
}

# Store WebSocket clients
ws_clients = []

# Store images
IMAGE_FOLDER = 'camera_images'
os.makedirs(IMAGE_FOLDER, exist_ok=True)

# Thresholds for automation
THRESHOLDS = {
    'temp_high': 30.0,
    'temp_low': 20.0,
    'moisture_low': 40,
    'moisture_high': 80,
    'intensity_low': 20,
    'intensity_high': 80
}

LOG_FILE = 'plant_monitor.log'

def log_message(message):
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    log_entry = f"[{timestamp}] {message}"
    print(log_entry)
    with open(LOG_FILE, 'a') as f:
        f.write(log_entry + '\n')

# ========================================
# WEB SOCKET ENDPOINT
# ========================================

@sock.route('/')
def camera_websocket(ws):
    log_message("ESP32-CAM connected via WebSocket")
    ws_clients.append(ws)
    camera_store['streaming'] = True
    
    try:
        # Send start streaming command
        ws.send(json.dumps({
            'type': 'control',
            'action': 'start_stream'
        }))
        log_message("Sent start_stream command to ESP32-CAM")
        
        while True:
            data = ws.receive()
            
            if data is None:
                break
            
            # Handle different message types
            if isinstance(data, str):
                try:
                    msg = json.loads(data)
                    msg_type = msg.get('type', '')
                    
                    if msg_type == 'connection':
                        device_id = msg.get('device_id', 'unknown')
                        camera_store['device_id'] = device_id
                        log_message(f"Camera device {device_id} connected")
                        
                        # Send configuration
                        ws.send(json.dumps({
                            'type': 'config',
                            'fps': 10,
                            'quality': 15,
                            'resolution': 'QVGA'
                        }))
                    
                    elif msg_type == 'status':
                        fps = msg.get('fps', 0)
                        frames = msg.get('frame_count', 0)
                        streaming = msg.get('streaming', False)
                        log_message(f"Camera status: Streaming={streaming}, FPS={fps}, Frames={frames}")
                        
                        # Update sensor data if included
                        if 'temperature' in msg:
                            sensor_data_store['sensor_node_1']['temperature'] = msg['temperature']
                        if 'humidity' in msg:
                            sensor_data_store['sensor_node_1']['humidity'] = msg['humidity']
                        if 'soil_moisture' in msg:
                            sensor_data_store['sensor_node_1']['soil_moisture'] = msg['soil_moisture']
                    
                    elif msg_type == 'config_ack':
                        log_message(f"Camera config acknowledged: {msg}")
                    
                except json.JSONDecodeError as e:
                    log_message(f"Invalid JSON received: {e}")
            
            elif isinstance(data, bytes):
                # Binary image data
                camera_store['latest_frame'] = base64.b64encode(data).decode('utf-8')
                camera_store['frame_count'] += 1
                camera_store['last_timestamp'] = datetime.now().isoformat()
                
                # Save every 50th frame
                if camera_store['frame_count'] % 50 == 0:
                    filename = f"capture_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jpg"
                    filepath = os.path.join(IMAGE_FOLDER, filename)
                    with open(filepath, 'wb') as f:
                        f.write(data)
                    log_message(f"Saved frame {camera_store['frame_count']} to {filename}")
    
    except Exception as e:
        log_message(f"WebSocket error: {str(e)}")
    
    finally:
        if ws in ws_clients:
            ws_clients.remove(ws)
        camera_store['streaming'] = False
        log_message("ESP32-CAM disconnected")

# ========================================
# FLASK ROUTES
# ========================================

@app.route('/')
def index():
    return send_file('index.html')

@app.route('/voice-test.html')
def voice_test():
    return send_file('voice-test.html')

@app.route('/live-feed.html')
def live_feed():
    return send_file('live-feed.html')

@app.route('/health-analysis.html')
def health_analysis():
    return send_file('health-analysis.html')

# ========================================
# FRUIT/VEGETABLE DETECTION API
# ========================================

@app.route('/api/detect', methods=['POST'])
def detect_fruit_vegetable():
    """Detect fruit or vegetable in uploaded image"""
    try:
        log_message("Fruit/vegetable detection requested")
        
        # Check if detector is available
        if not DETECTOR_AVAILABLE or detector is None:
            return jsonify({
                'error': 'Fruit/vegetable detector not available',
                'tip': 'Make sure PyTorch is installed and model is in models/ folder'
            }), 500
        
        # Get image data
        img_data = None
        img_format = None
        
        # Check for base64 image
        if request.json and 'image' in request.json:
            img_b64 = request.json['image']
            if img_b64.startswith('data:image/'):
                # Extract base64 data
                img_b64 = img_b64.split(',', 1)[1]
                img_format = img_b64.split(';')[0].split('/')[1] if ';' in img_b64 else 'jpeg'
            
            img_data = base64.b64decode(img_b64)
            log_message(f"Received base64 image ({len(img_data)} bytes)")
        
        # Check for file upload
        elif 'file' in request.files:
            file = request.files['file']
            img_data = file.read()
            img_format = file.filename.split('.')[-1] if '.' in file.filename else 'jpeg'
            log_message(f"Received file upload: {file.filename} ({len(img_data)} bytes)")
        
        if not img_data:
            return jsonify({'error': 'No image data provided'}), 400
        
        # Convert to PIL Image
        img = Image.open(BytesIO(img_data)).convert('RGB')
        
        # Get detection results
        results = detector.predict(img_data)
        
        if not results:
            return jsonify({'error': 'No detection results'}), 500
        
        # Get top result
        top_result = results[0]
        label = top_result['label']
        confidence = top_result['confidence']
        
        # VALIDATION: Check if detected object is a valid fruit or vegetable
        # Enhanced validation checks confidence, entropy, and probability margins
        is_valid, error_message = detector.is_valid_fruit_vegetable(top_result)
        
        if not is_valid:
            log_message(f"Invalid object detected: {label} ({confidence*100:.1f}%) - Not a fruit/vegetable")
            return jsonify({
                'success': False,
                'error': 'Invalid object detected',
                'message': error_message,
                'detected_object': label,
                'confidence': round(confidence * 100, 2),
                'suggestions': [
                    'Please upload an image containing fruits or vegetables only',
                    'Ensure the image clearly shows the produce',
                    'Supported items: apples, bananas, carrots, tomatoes, etc.'
                ],
                'timestamp': datetime.now().isoformat()
            }), 400
        
        # Confidence threshold: if below 5%, consider data quality poor
        # 5% is very lenient; only true noise should fall below this
        CONFIDENCE_THRESHOLD = 0.05
        
        if confidence < CONFIDENCE_THRESHOLD:
            # Poor data quality - return message instead of prediction
            log_message(f"Low confidence detection: {label} ({confidence*100:.1f}%) - Below threshold, returning poor data message")
            
            return jsonify({
                'success': False,
                'error': 'Poor data quality',
                'message': 'Unable to detect clearly. Please ensure:',
                'suggestions': [
                    'Image shows a clear fruit/vegetable',
                    'Good lighting conditions',
                    'Image is not blurry or zoomed too far',
                    'Try capturing from a different angle'
                ],
                'timestamp': datetime.now().isoformat()
            }), 200
        
        # Get fun fact
        fun_fact = detector.get_fun_fact(label)
        
        # Convert image to base64 for disease detection
        raw_image_b64 = 'data:image/jpeg;base64,' + base64.b64encode(img_data).decode('utf-8')
        
        # Create response
        response = {
            'success': True,
            'detection': {
                'label': label,
                'confidence': confidence,
                'confidence_percent': round(confidence * 100, 2)
            },
            'fun_facts': fun_fact,
            'timestamp': datetime.now().isoformat(),
            'top_predictions': results[:3],  # Top 3 predictions
            'raw_image_data': raw_image_b64  # Include for disease detection
        }
        
        log_message(f"Detection: {label} ({confidence*100:.1f}%) - {fun_fact['fact']}")
        
        # Store latest detection for voice commands
        latest_detection['fruit_name'] = label
        latest_detection['confidence'] = confidence
        latest_detection['timestamp'] = datetime.now().isoformat()
        
        return jsonify(response), 200
    
    except Exception as e:
        log_message(f"Detection error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/api/detect/latest', methods=['GET'])
def get_latest_detection():
    """Get the latest fruit/vegetable detection for voice commands"""
    try:
        if latest_detection['fruit_name']:
            return jsonify(latest_detection), 200
        else:
            return jsonify({
                'fruit_name': None,
                'confidence': 0,
                'message': 'No recent detection available'
            }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/detect-disease', methods=['POST'])
def detect_disease():
    """Detect plant disease in uploaded image"""
    try:
        log_message("Disease detection requested")
        
        # Check if disease detector is available
        if not DISEASE_DETECTOR_AVAILABLE or disease_detector is None:
            return jsonify({
                'error': 'Disease detector not available',
                'tip': 'Run python train_disease_model.py to train the disease detection model'
            }), 500
        
        # Get image data
        img_data = None
        
        # Check for base64 image in JSON
        try:
            if request.json and 'image' in request.json:
                img_b64 = request.json['image']
                if img_b64.startswith('data:image/'):
                    img_b64 = img_b64.split(',', 1)[1]
                img_data = base64.b64decode(img_b64)
                log_message(f"Received base64 image ({len(img_data)} bytes)")
        except:
            pass
        
        # Check for file upload (form data)
        if not img_data and 'file' in request.files:
            file = request.files['file']
            img_data = file.read()
            log_message(f"Received file upload: {file.filename}")
        
        if not img_data:
            return jsonify({'error': 'No image data provided'}), 400
        
        # Convert to PIL Image
        img = Image.open(BytesIO(img_data)).convert('RGB')
        
        # Apply transform
        img_tensor = disease_detector['transform'](img).unsqueeze(0)
        
        # Get prediction
        with torch.no_grad():
            outputs = disease_detector['model'](img_tensor)
            probabilities = torch.nn.functional.softmax(outputs, dim=1)
            confidence, predicted = torch.max(probabilities, 1)
        
        # Get disease class - handle index bounds
        pred_idx = predicted.item()
        if pred_idx < len(disease_detector['classes']):
            disease_class = disease_detector['classes'][pred_idx]
        else:
            disease_class = f"Class_{pred_idx}"
        
        confidence_score = confidence.item()
        
        # Get disease information
        disease_info = get_disease_info(disease_class)
        
        # Create response
        response = {
            'success': True,
            'disease_class': disease_class,
            'confidence': confidence_score,
            'confidence_percent': round(confidence_score * 100, 2),
            'crop': disease_info.get('crop', 'Unknown'),
            'disease_name': disease_info.get('disease', disease_class),
            'severity': disease_info.get('severity', 'Unknown'),
            'symptoms': disease_info.get('symptoms', 'No symptoms data'),
            'causes': disease_info.get('causes', 'No causes data'),
            'treatment': disease_info.get('treatment', 'Consult agricultural expert'),
            'prevention': disease_info.get('prevention', 'Maintain proper care'),
            'timestamp': datetime.now().isoformat()
        }
        
        log_message(f"Disease detected: {response['disease_name']} ({confidence_score*100:.1f}%)")
        
        # Store latest disease detection
        latest_detection['disease'] = response['disease_name']
        latest_detection['disease_confidence'] = confidence_score
        latest_detection['disease_details'] = disease_info
        latest_detection['timestamp'] = datetime.now().isoformat()
        
        return jsonify(response), 200
    
    except Exception as e:
        log_message(f"Disease detection error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/api/detect/test', methods=['GET'])
def test_detection():
    """Test endpoint to verify detection is working"""
    try:
        # Create a simple test image (red square)
        img = Image.new('RGB', (224, 224), color='red')
        img_bytes = BytesIO()
        img.save(img_bytes, format='JPEG')
        
        if detector:
            results = detector.predict(img_bytes.getvalue())
            return jsonify({
                'status': 'detector_working',
                'test_results': results[:3]
            })
        else:
            return jsonify({
                'status': 'detector_not_available',
                'message': 'Fruit/vegetable detector not initialized'
            })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ========================================
# SENSOR NODE APIs
# ========================================

@app.route('/api/sensor-data', methods=['POST'])
def receive_sensor_data():
    """Receive sensor data from ESP32 Sensor Node"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No data received'}), 400
        
        device_id = data.get('device_id', 'sensor_node_1')
        
        # Update sensor data
        sensor_data_store[device_id] = {
            'temperature': float(data.get('temperature', 24.5)),
            'humidity': float(data.get('humidity', 65.0)),
            'soil_moisture': int(data.get('soil_moisture', 60)),
            'light_intensity': int(data.get('light_intensity', 0)),
            'fan_state': bool(data.get('fan_state', False)),
            'pump_state': bool(data.get('pump_state', False)),
            'bulb_state': bool(data.get('bulb_state', False)),
            'last_updated': datetime.now().isoformat()
        }
        
        log_message(f"Sensor data: T={sensor_data_store[device_id]['temperature']}°C, H={sensor_data_store[device_id]['humidity']}%, S={sensor_data_store[device_id]['soil_moisture']}%")
        
        # Apply automatic control if not in manual mode
        if not command_store[device_id]['fan_manual']:
            if sensor_data_store[device_id]['temperature'] > THRESHOLDS['temp_high']:
                command_store[device_id]['fan_state'] = True
            elif sensor_data_store[device_id]['temperature'] < THRESHOLDS['temp_low']:
                command_store[device_id]['fan_state'] = False
        
        if not command_store[device_id]['pump_manual']:
            if sensor_data_store[device_id]['soil_moisture'] < THRESHOLDS['moisture_low']:
                command_store[device_id]['pump_state'] = True
            elif sensor_data_store[device_id]['soil_moisture'] > THRESHOLDS['moisture_high']:
                command_store[device_id]['pump_state'] = False
        
        if not command_store[device_id]['bulb_manual']:
            # Simple logic for bulb control based on time or light intensity
            current_hour = datetime.now().hour
            if 6 <= current_hour <= 18:
                command_store[device_id]['bulb_state'] = False  # Daytime
            else:
                command_store[device_id]['bulb_state'] = True   # Nighttime
        
        return jsonify({'status': 'success', 'message': 'Data received'}), 200
    
    except Exception as e:
        log_message(f"Error receiving sensor data: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/sensor-data', methods=['GET'])
def get_sensor_data():
    """Get latest sensor data for dashboard"""
    try:
        device_id = request.args.get('device_id', 'sensor_node_1')
        if device_id not in sensor_data_store:
            return jsonify({'error': 'Device not found'}), 404
        
        # Add detection status if available
        data = sensor_data_store[device_id].copy()
        data['detector_available'] = DETECTOR_AVAILABLE
        
        return jsonify(data), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ========================================
# COMMAND APIs
# ========================================

@app.route('/api/commands/<device_id>', methods=['GET'])
def get_commands(device_id):
    """ESP32 Sensor Node checks for commands"""
    try:
        if device_id not in command_store:
            command_store[device_id] = {
                'fan_manual': False,
                'fan_state': False,
                'pump_manual': False,
                'pump_state': False,
                'bulb_manual': False,
                'bulb_state': False,
                'server_ip': '10.206.250.110'
            }
        return jsonify(command_store[device_id]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/commands/<device_id>', methods=['POST'])
def send_commands(device_id):
    """Web dashboard sends commands to control sensor node"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No data received'}), 400
        
        if device_id not in command_store:
            command_store[device_id] = {
                'fan_manual': False,
                'fan_state': False,
                'pump_manual': False,
                'pump_state': False,
                'bulb_manual': False,
                'bulb_state': False,
                'server_ip': '10.206.250.110'
            }
        
        # Update commands
        updates = []
        if 'fan_manual' in data:
            command_store[device_id]['fan_manual'] = bool(data['fan_manual'])
            updates.append(f"fan_manual={command_store[device_id]['fan_manual']}")
        
        if 'fan_state' in data:
            command_store[device_id]['fan_state'] = bool(data['fan_state'])
            updates.append(f"fan_state={command_store[device_id]['fan_state']}")
        
        if 'pump_manual' in data:
            command_store[device_id]['pump_manual'] = bool(data['pump_manual'])
            updates.append(f"pump_manual={command_store[device_id]['pump_manual']}")
        
        if 'pump_state' in data:
            command_store[device_id]['pump_state'] = bool(data['pump_state'])
            updates.append(f"pump_state={command_store[device_id]['pump_state']}")
        
        if 'bulb_manual' in data:
            command_store[device_id]['bulb_manual'] = bool(data['bulb_manual'])
            updates.append(f"bulb_manual={command_store[device_id]['bulb_manual']}")
        
        if 'bulb_state' in data:
            command_store[device_id]['bulb_state'] = bool(data['bulb_state'])
            updates.append(f"bulb_state={command_store[device_id]['bulb_state']}")
        
        if updates:
            log_message(f"{device_id} commands updated: {', '.join(updates)}")
        
        return jsonify({'status': 'success', 'message': 'Commands updated'}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ========================================
# CAMERA APIs
# ========================================

@app.route('/api/camera-feed', methods=['GET', 'POST'])
def get_camera_feed():
    """Web dashboard gets latest camera frame"""
    try:
        if not camera_store['latest_frame']:
            return jsonify({'error': 'No frame available'}), 404
        
        return jsonify({
            'image': camera_store['latest_frame'],
            'timestamp': camera_store['last_timestamp'],
            'frame_count': camera_store['frame_count'],
            'device_id': camera_store['device_id'],
            'streaming': camera_store['streaming']
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/camera/control', methods=['POST'])
def camera_control():
    """Send control commands to camera via WebSocket"""
    try:
        data = request.get_json()
        action = data.get('action')
        
        if not ws_clients:
            return jsonify({'error': 'Camera not connected'}), 404
        
        # Send command to all connected cameras
        for ws in ws_clients:
            try:
                ws.send(json.dumps({
                    'type': 'control',
                    'action': action
                }))
                log_message(f"Sent camera command: {action}")
            except Exception as e:
                log_message(f"Error sending to camera: {e}")
        
        return jsonify({'status': 'success'}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ========================================
# SYSTEM APIs
# ========================================

@app.route('/api/status')
def get_status():
    """Get overall system status"""
    return jsonify({
        'status': 'running',
        'timestamp': datetime.now().isoformat(),
        'sensor_nodes': len(sensor_data_store),
        'camera_connected': len(ws_clients) > 0,
        'camera_streaming': camera_store['streaming'],
        'frame_count': camera_store['frame_count'],
        'detector_available': DETECTOR_AVAILABLE,
        'detector_initialized': detector is not None
    }), 200

@app.route('/api/thresholds', methods=['GET'])
def get_thresholds():
    """Get control thresholds"""
    return jsonify(THRESHOLDS), 200

@app.route('/api/thresholds', methods=['POST'])
def update_thresholds():
    """Update control thresholds"""
    try:
        data = request.get_json()
        
        updates = []
        if 'temp_high' in data:
            THRESHOLDS['temp_high'] = float(data['temp_high'])
            updates.append(f"temp_high={THRESHOLDS['temp_high']}")
        
        if 'temp_low' in data:
            THRESHOLDS['temp_low'] = float(data['temp_low'])
            updates.append(f"temp_low={THRESHOLDS['temp_low']}")
        
        if 'moisture_low' in data:
            THRESHOLDS['moisture_low'] = int(data['moisture_low'])
            updates.append(f"moisture_low={THRESHOLDS['moisture_low']}")
        
        if 'moisture_high' in data:
            THRESHOLDS['moisture_high'] = int(data['moisture_high'])
            updates.append(f"moisture_high={THRESHOLDS['moisture_high']}")
        
        if 'intensity_low' in data:
            THRESHOLDS['intensity_low'] = int(data['intensity_low'])
            updates.append(f"intensity_low={THRESHOLDS['intensity_low']}")
        
        if 'intensity_high' in data:
            THRESHOLDS['intensity_high'] = int(data['intensity_high'])
            updates.append(f"intensity_high={THRESHOLDS['intensity_high']}")
        
        if updates:
            log_message(f"Thresholds updated: {', '.join(updates)}")
        
        return jsonify({'status': 'success', 'thresholds': THRESHOLDS}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/system-info', methods=['GET'])
def get_system_info():
    """Get detailed system information"""
    import platform
    import sys
    
    info = {
        'python_version': sys.version,
        'platform': platform.platform(),
        'processor': platform.processor(),
        'system': platform.system(),
        'machine': platform.machine(),
        'detector': {
            'available': DETECTOR_AVAILABLE,
            'type': str(type(detector)) if detector else 'None',
            'device': detector.device if detector and hasattr(detector, 'device') else 'unknown'
        },
        'directories': {
            'working_dir': os.getcwd(),
            'models_dir': 'models' if os.path.exists('models') else 'not found',
            'datasets_dir': 'datasets' if os.path.exists('datasets') else 'not found',
            'images_dir': IMAGE_FOLDER if os.path.exists(IMAGE_FOLDER) else 'not found'
        }
    }
    
    return jsonify(info), 200

# ========================================
# TRAINING ENDPOINTS
# ========================================

@app.route('/api/train', methods=['POST'])
def train_model_api():
    """Train the fruit/vegetable detection model via API"""
    try:
        if not TORCH_AVAILABLE:
            return jsonify({'error': 'PyTorch not available for training'}), 500
        
        data = request.get_json() or {}
        epochs = data.get('epochs', 10)
        dataset_path = data.get('dataset_path', 'datasets/fruits_vegetables')
        
        if not os.path.exists(dataset_path):
            return jsonify({'error': f'Dataset not found at {dataset_path}'}), 404
        
        # Run training in a separate thread to avoid blocking
        def train_in_background():
            try:
                detector.train(dataset_path, epochs=epochs, save_path='models/fruit_veg_model.pth')
                log_message(f"Training completed via API")
            except Exception as e:
                log_message(f"Training error: {e}")
        
        threading.Thread(target=train_in_background, daemon=True).start()
        
        return jsonify({
            'status': 'started',
            'message': 'Training started in background',
            'epochs': epochs,
            'dataset_path': dataset_path
        }), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ========================================
# UTILITY FUNCTIONS
# ========================================

def cleanup_old_images():
    """Clean up images older than 7 days"""
    while True:
        try:
            current_time = time.time()
            deleted_count = 0
            
            if os.path.exists(IMAGE_FOLDER):
                for filename in os.listdir(IMAGE_FOLDER):
                    filepath = os.path.join(IMAGE_FOLDER, filename)
                    if os.path.isfile(filepath):
                        if current_time - os.path.getmtime(filepath) > 7 * 24 * 3600:
                            os.remove(filepath)
                            deleted_count += 1
                
                if deleted_count > 0:
                    log_message(f"Cleaned up {deleted_count} old images")
        
        except Exception as e:
            log_message(f"Cleanup error: {str(e)}")
        
        time.sleep(3600)  # Run every hour

def setup_directories():
    """Create necessary directories"""
    directories = ['models', 'datasets', 'camera_images']
    for directory in directories:
        os.makedirs(directory, exist_ok=True)
        print(f"Created directory: {directory}")

def check_dependencies():
    """Check if required dependencies are installed"""
    try:
        import flask
        import flask_cors
        import flask_sock
        import PIL
        print("[OK] Flask dependencies installed")
    except ImportError as e:
        print(f"[ERROR] Missing dependency: {e}")
        print("Install with: pip install flask flask-cors flask-sock pillow")
        return False
    
    if not TORCH_AVAILABLE:
        print("[WARNING] PyTorch not installed. Fruit detection will be limited.")
        print("Install with: pip install torch torchvision")
    
    return True

def train_model_command(args=None):
    """Command line function to train the model"""
    if not TORCH_AVAILABLE:
        print("[ERROR] PyTorch not available. Cannot train model.")
        return
    
    dataset_path = getattr(args, 'train_dataset', None) or 'datasets/fruits_vegetables'
    train_epochs = getattr(args, 'train_epochs', None) or 20
    save_path = getattr(args, 'train_save', None) or 'models/fruit_veg_model.pth'
    train_batch_size = getattr(args, 'train_batch_size', None) or 32
    train_lr = getattr(args, 'train_lr', None) or 3e-4
    if not os.path.exists(dataset_path):
        print(f"[ERROR] Dataset not found at {dataset_path}")
        print("Please download the dataset first")
        return
    
    print("=" * 60)
    print("TRAINING FRUIT/VEGETABLE DETECTION MODEL")
    print("=" * 60)
    
    # Create detector
    detector = FruitVegetableDetector()
    
    # Train the model
    detector.train(
        dataset_path=dataset_path,
        epochs=train_epochs,
        save_path=save_path,
        batch_size=train_batch_size,
        lr=train_lr,
        num_workers=4
    )

# ========================================
# MAIN ENTRY POINT
# ========================================

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Plant Monitor Server with Fruit/Vegetable Detection')
    parser.add_argument('--train', action='store_true', help='Train the fruit/vegetable model')
    parser.add_argument('--train-epochs', type=int, default=20, help='Number of training epochs (default: 20)')
    parser.add_argument('--train-dataset', type=str, default='datasets/fruits_vegetables', help='Dataset root path containing train/ and test/ folders')
    parser.add_argument('--train-save', type=str, default='models/fruit_veg_model.pth', help='Path to save trained model')
    parser.add_argument('--train-batch-size', type=int, default=32, help='Batch size for training (default: 32; reduce if GPU memory is limited)')
    parser.add_argument('--train-lr', type=float, default=3e-4, help='Learning rate for training (default: 3e-4)')
    parser.add_argument('--setup', action='store_true', help='Setup directories and check dependencies')
    parser.add_argument('--port', type=int, default=5000, help='Port to run the server on')
    parser.add_argument('--open-chrome', action='store_true', help='Open voice test page in Google Chrome on start')
    
    args = parser.parse_args()
    
    # Setup directories
    setup_directories()
    
    # Check dependencies
    if not check_dependencies():
        print("[ERROR] Please install required dependencies")
        sys.exit(1)
    
    # Handle commands
    if args.train:
        train_model_command(args)
        sys.exit(0)
    
    if args.setup:
        print("[OK] Setup completed")
        sys.exit(0)
    
    # Start cleanup thread
    cleanup_thread = threading.Thread(target=cleanup_old_images, daemon=True)
    cleanup_thread.start()
    
    # Start server
    print("=" * 60)
    print("FRUIT & VEGETABLE PLANT MONITOR SERVER")
    print("=" * 60)
    print(f"Fruit/Vegetable Detector: {'[OK] AVAILABLE' if DETECTOR_AVAILABLE else '[ERROR] NOT AVAILABLE'}")
    print("\nServer Endpoints:")
    print(f"  - Web Dashboard:      http://localhost:{args.port}")
    print(f"  - Live Feed:          http://localhost:{args.port}/live-feed.html")
    print(f"  - Fruit Detection:    POST http://localhost:{args.port}/api/detect")
    print("\n[NOTE] For microphone access, open via localhost or HTTPS.")
    print("\n[CONNECTIONS] ESP32 Connections:")
    print(f"  - Sensor Node (HTTP): POST http://0.0.0.0:{args.port}/api/sensor-data")
    print(f"  - Camera (WebSocket): ws://0.0.0.0:{args.port}/")
    print("\n[CONFIG] Commands:")
    print("  - Train model: python server.py --train")
    print("  - Setup:       python server.py --setup")
    print("=" * 60)
    print(f"Server starting on port {args.port}... Press Ctrl+C to stop")
    print("=" * 60)
    
    try:
        # Optionally open Chrome to voice test page (after a short delay)
        if args.open_chrome:
            def open_in_chrome(url):
                paths = [
                    r"C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
                    r"C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe"
                ]
                for p in paths:
                    if os.path.exists(p):
                        try:
                            subprocess.Popen([p, url])
                            return True
                        except Exception:
                            pass
                try:
                    webbrowser.open_new(url)
                    return True
                except Exception:
                    return False
            threading.Timer(1.5, lambda: open_in_chrome(f"http://localhost:{args.port}/voice-test.html")).start()
        
        app.run(host='0.0.0.0', port=args.port, debug=False, threaded=True)
    except KeyboardInterrupt:
        print("\nServer stopped by user")
    except Exception as e:
        print(f"Server error: {e}")